<?php      
 include('connection.php'); 
    if(isset($_POST['message']))
{	 
	 
	 $name = $_POST['name'];
	 $email = $_POST['email'];
	 $message = $_POST['message'];
	$fromdate = $_POST['fromdate'];
	$todate = $_POST['todate'];
	 $sql = "INSERT INTO outpass (name,email,message,fromdate,todate)
	 VALUES ('$name','$email','$message','$fromdate','$todate')";
	 if (mysqli_query($con, $sql)) {
		   echo "REGISTERD SUCCESSFULLY";
			header("location:http://localhost/DT/hostelmate/Login_v12/CoolAdmin-master/index.html");
	 } else {
		echo "Error: " . $sql . "
		
" . mysqli_error($con);
	 }
	 mysqli_close($con);
}
?>  