<?php      
 include('connection.php'); 
    if(isset($_POST['message']))
{	 
	 $choice = $_POST['choice'];
	 $name = $_POST['name'];
	 $email = $_POST['email'];
	 $message = $_POST['message'];
	 $sql = "INSERT INTO complaint (about,name,emailid,message)
	 VALUES ('$choice','$name','$email','$message')";
	 if (mysqli_query($con, $sql)) {
		   echo "REGISTERD SUCCESSFULLY";
			header("location:http://localhost/DT/hostelmate/Login_v12/CoolAdmin-master/index.html");
	 } else {
		echo "Error: " . $sql . "
		
" . mysqli_error($con);
	 }
	 mysqli_close($con);
}
?>  