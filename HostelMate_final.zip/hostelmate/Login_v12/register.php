<?php      
 include('connection.php'); 
    if(isset($_POST['phno']))
{	 
	 $username = $_POST['username'];
	 $password = $_POST['password'];
	 $phno = $_POST['phno'];
	 $sql = "INSERT INTO register (username,password,phno)
	 VALUES ('$username','$password','$phno')";
	 if (mysqli_query($con, $sql)) {
		   echo "REGISTERD SUCCESSFULLY";
		header("location:http://localhost/DT/hostelmate/Login_v12/registersuccessfull.html");
	 } else {
		echo "Error: " . $sql . "
		
" . mysqli_error($con);
	 }
	 mysqli_close($con);
}
?>  