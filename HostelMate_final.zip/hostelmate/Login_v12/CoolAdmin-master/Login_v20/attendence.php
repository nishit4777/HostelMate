<?php      
 include('connection.php'); 
    if(isset($_POST['attendance']))
{	 
	 
	$todate = $_POST['date'];
	 $attendance = $_POST['attendance'];
	 
	
	 $sql = "INSERT INTO attendence (mark,date)
	 VALUES ('$todate','$attendance')";
	 if (mysqli_query($con, $sql)) {
		   echo "REGISTERD SUCCESSFULLY";
			header("location:http://localhost/DT/hostelmate/Login_v12/CoolAdmin-master/index.html");
	 } else {
		echo "Error: " . $sql . "
		
" . mysqli_error($con);
	 }
	 mysqli_close($con);
}
?>  